# Open DART 기업분석 자동화 도구

이 프로젝트는 Open DART API를 활용하여 기업의 재무정보, 공시정보 등을 수집하고, 자동 분석하는 시스템입니다.

## 주요 기능
- 기업 리스트 기반 자동 데이터 수집
- 재무제표 정리 및 시각화
- JSON 결과 저장

## 사용 기술
- Python
- Open DART API
- Pandas / Requests

## 확인 URL
https://github.com/CBNURecommender/opendart-analyzer
