import requests
import json
import pandas as pd

API_KEY = "여기에_발급받은_API_KEY_입력"
corp_code = "00126380"  # 삼성전자 예시

url = f"https://opendart.fss.or.kr/api/fnlttSinglAcnt.json?crtfc_key={API_KEY}&corp_code={corp_code}&bsns_year=2023&reprt_code=11011"

res = requests.get(url)
data = res.json()

# 저장
with open('data/sample_output.json', 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=4)

print("데이터 수집 완료!")
